package com.example.kenshiclckr;

import static android.view.View.VISIBLE;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import androidx.activity.EdgeToEdge;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;
import android.os.Handler;
import android.os.Looper;
import android.widget.Toast;

public class Game extends AppCompatActivity {
    int fullHealth = 100; int Health2 = 100; int Heal1 = 5; int Heal2 = 15;
    int EnemyMinAttk = 1; int EnemyMaxAttk = 10; int Attk1 = 5; int Attk2 = 15;
    int EnemHP1 = 75; int EnemHP2 = 225; int EnemyFullHP = 0;
    int EnemyHealth = (int) (Math.random() * ((EnemHP2 - EnemHP1) + 1)) + EnemHP1;

    int Rnd = 1; int Rnd2 = 3;

    @RequiresApi(api = Build.VERSION_CODES.VANILLA_ICE_CREAM)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_game);
        Toast toast = Toast.makeText(getApplicationContext(), "Пора покорять пустоши!", Toast.LENGTH_LONG);
        toast.show();
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        @Override
        public boolean onCreateOptionsMenu(Menu menu) {
            
        }

        View deadView = findViewById(R.id.deadview);
        TextView Clicks = findViewById(R.id.textView);
        TextView PlfullHealths = findViewById(R.id.PlfullHealth);
        TextView Health = findViewById(R.id.HP);
        ImageButton Clckr = findViewById(R.id.Clicker);
        ImageButton defend = findViewById(R.id.defends);
        ImageButton Bandage = findViewById(R.id.usebandage);

        final Handler handler = new Handler(Looper.getMainLooper());
        Runnable checkRunnable = new Runnable() {
            @Override
            public void run() {
                if (EnemyHealth <= 0) {
                    EnemyHealth = (int) (Math.random() * ((EnemHP2 - EnemHP1) + 1)) + EnemHP1;
                    EnemyFullHP = EnemyHealth;
                    Clicks.setText(String.valueOf(EnemyHealth));
                }

                if (Health2 <= 0) {
                    Health.setText(String.valueOf(0));
                    Clckr.setEnabled(false);
                    Bandage.setEnabled(false);
                    defend.setEnabled(false);
                    deadView.setVisibility(VISIBLE);
                }

                /*if (EnemyFullHP - EnemyHealth >= 20){
                    int EnemyHeal = (int) (Math.random() * ((Heal2 - Heal1) + 1)) + Heal1;
                }*/
                handler.postDelayed(this, 100);
            }
        };
        handler.post(checkRunnable);
        Clicks.setText(String.valueOf(EnemyHealth));

        defend.setOnClickListener(View ->{
            int EnemyAttack = (int) (Math.random() * ((EnemyMaxAttk - EnemyMinAttk) + 1)) + EnemyMinAttk;
            Health2 -= EnemyAttack/2;
            fullHealth -= EnemyAttack/3;

            Clicks.setText(String.valueOf(EnemyHealth));
            Health.setText(String.valueOf(Health2));
            PlfullHealths.setText(String.valueOf(fullHealth));
        });

        Clckr.setOnClickListener(View ->{
            int PlAttack = (int) (Math.random() * ((Attk2 - Attk1) + 1)) + Attk1;
            EnemyHealth -= PlAttack;
            int EnemyAttack = (int) (Math.random() * ((EnemyMaxAttk - EnemyMinAttk) + 1)) + EnemyMinAttk;
            Health2 -= EnemyAttack;

            Clicks.setText(String.valueOf(EnemyHealth));
            Health.setText(String.valueOf(Health2));
            fullHealth -= EnemyAttack/2;
            PlfullHealths.setText(String.valueOf(fullHealth));
        });

        Bandage.setOnClickListener(View ->{
            int EnemyAttack = (int) (Math.random() * ((EnemyMaxAttk - EnemyMinAttk) + 1)) + EnemyMinAttk;
            int Heal = (int) (Math.random() * ((Heal1 - Heal2) + 1)) + Heal2;
            Health2 = Health2 - EnemyAttack + Heal;
            fullHealth -= EnemyAttack/3;
            PlfullHealths.setText(String.valueOf(fullHealth));
            if (fullHealth < Health2) {
                Health2 = fullHealth;
                Health.setText(String.valueOf(Health2));
            }

            Clicks.setText(String.valueOf(EnemyHealth));
            Health.setText(String.valueOf(Health2));
            PlfullHealths.setText(String.valueOf(fullHealth));
        });
    }
}